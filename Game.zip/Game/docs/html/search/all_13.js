var searchData=
[
  ['vector2d_213',['Vector2D',['../struct_vector2_d.html',1,'Vector2D'],['../struct_vector2_d.html#aa666ef9e6d697c5090f193baefe16f66',1,'Vector2D::Vector2D()=default'],['../struct_vector2_d.html#ab34332f542a2eef92e4a52548f753587',1,'Vector2D::Vector2D(float a, float b)']]],
  ['velocity_214',['velocity',['../class_game_entity.html#a084860ac892e7cde25f56c7be3936f3d',1,'GameEntity']]]
];
