var searchData=
[
  ['coin_487',['coin',['../_constants_8hpp.html#ac25bae40f86dbaf62807318d4042d75ca8283ef333c76d3e991b716ce9010dd14',1,'Constants.hpp']]]
];
