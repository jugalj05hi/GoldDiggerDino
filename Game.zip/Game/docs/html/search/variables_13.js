var searchData=
[
  ['x_481',['x',['../struct_vector2_d.html#aeb4253ba6555251d010ea4450619029e',1,'Vector2D']]],
  ['xpostile_482',['xPosTile',['../class_game_entity.html#a885e716f6636f35eedd898c64eb9859f',1,'GameEntity']]]
];
