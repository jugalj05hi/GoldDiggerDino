var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvwxy~",
  1: "acegilprstv",
  2: "acegilprst",
  3: "acdeghilmnoprstuvw~",
  4: "abcdefghijlmoprstvwxy",
  5: "ce",
  6: "bcdelmnrt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

