#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include "Characters.hpp"
#include <SDL2_image/SDL_image.h>


// Try toggling this number!

// Just a cheap little class to demonstrate loading characters.
class ResourceManager{
public:



	static ResourceManager& getInstance();


	void init(std::string filename,SDL_Renderer* ren);


	SDL_Texture* getTexture();
	int startUp();
	int shutdown();


private:

	ResourceManager* instance=NULL;
	// SDL_Surface *spriteSheet;

	SDL_Texture *textures;
	std::map<std::string, SDL_Texture*> surfaces;


	 ResourceManager();
	 ~ResourceManager();   // Private Singleton
	 ResourceManager(ResourceManager const&); // Avoid copy constructor
	 void operator=(ResourceManager const&); // Don't allow assignment.

};

#endif
