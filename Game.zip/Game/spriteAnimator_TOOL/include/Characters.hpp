#ifndef CHARACTERS_HPP
#define CHARACTERS_HPP

#include <map>
#include <string>
#include <memory>
#include <iterator>




class Characters{
public:

	Characters();

	~Characters();

	void init(int x, int y, SDL_Renderer* ren);

	void update(int x, int y, int frame);

	void render(SDL_Renderer* ren);
	void setInformation(std::string filename, int w, int h, int frameS, int frameE);

	int testVal=0;

private:
	int xPos, yPos, widthImg, heightImg,row,col,tempWidth, tempHeight;
	int tileHeight, tileWidth;
	 int currentFrame=0;
	 int lastFrame;
	 int startFrame;

	std::map<int, std::vector<int>> map;

	std::string filePath;

	SDL_Texture *texture;

	SDL_Rect Src;
	SDL_Rect Dest;
};

#endif
