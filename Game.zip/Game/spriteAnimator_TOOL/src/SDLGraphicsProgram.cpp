#include "SDLGraphicsProgram.hpp"
#include "ResourceManager.hpp"
#include "Characters.hpp"


// Try toggling this number!
#define CHARACTERS 1

// Global array to create our characters
Characters characters[CHARACTERS];

// Initialization function
// Returns a true or false value based on successful completion of setup.
// Takes in dimensions of window.
SDLGraphicsProgram::SDLGraphicsProgram(int w, int h):screenWidth(w),screenHeight(h){
  	// Initialize random number generation.
   	srand(time(NULL));

	 // Initialization flag
	 bool success = true;
	 // String to hold any errors that occur.
	 std::stringstream errorStream;
	 // The window we'll be rendering to
	 gWindow = NULL;
	 // Render flag

	// Initialize SDL
	if(SDL_Init(SDL_INIT_EVERYTHING)< 0){
		errorStream << "SDL could not initialize! SDL Error: " << SDL_GetError() << "\n";
		success = false;
	}
	else{
		//Create window
		gWindow = SDL_CreateWindow( "Lab", 100, 100, screenWidth, screenHeight, SDL_WINDOW_SHOWN );

		// Check if Window did not create.
		if( gWindow == NULL ){
			errorStream << "Window could not be created! SDL Error: " << SDL_GetError() << "\n";
			success = false;
		}

		//Create a Renderer to draw on
		gRenderer = SDL_CreateRenderer(gWindow, -1, SDL_RENDERER_ACCELERATED);
		// Check if Renderer did not create.
		if( gRenderer == NULL ){
			errorStream << "Renderer could not be created! SDL Error: " << SDL_GetError() << "\n";
			success = false;
		}
	}



    // Setup our characters
    // Remember, this can only be done after SDL has been
    // successfully initialized!
    // Here I am just building a little grid of characters




  // If initialization did not work, then print out a list of errors in the constructor.
  if(!success){
    	errorStream << "Failed to initialize!\n";
    	std::string errors=errorStream.str();
    	std::cout << errors << "\n";
  }else{
    	std::cout << "No SDL errors Detected in during init\n\n";
  }
}

void SDLGraphicsProgram::getSpriteInformation(std::string filePath, int tileWid,int tileH, int startFrame, int lastFrame){
  frameStart=startFrame;
  frameEnd=lastFrame;
  std::cout<<"yo";
  std::cout<<frameStart;
  std::cout<<frameEnd;

  tempPath=filePath;
  std::cout<<tempPath;
  characters[0].setInformation(filePath,tileWid,tileH,frameStart,frameEnd);


}



// Proper shutdown and destroy initialized objects
SDLGraphicsProgram::~SDLGraphicsProgram(){
    // Destroy Renderer
    SDL_DestroyRenderer(gRenderer);
    //Destroy window
    SDL_DestroyWindow( gWindow );
    // Point gWindow to NULL to ensure it points to nothing.
    gRenderer = NULL;
    gWindow = NULL;
    //Quit SDL subsystems
    SDL_Quit();
}



// Update OpenGL
void SDLGraphicsProgram::update()
{
    static int frame =frameStart ;
    frame++;
    if(frame>frameEnd){
      frame=frameStart;
    }
    // Nothing yet!
    // for(int i =0; i < CHARACTERS; i++){
    characters[0].update(20,20,frame);
    // }
}


// Render
// The render function gets called once per loop
void SDLGraphicsProgram::render(){

    SDL_SetRenderDrawColor(gRenderer, 0x22,0x22,0x22,0xFF);
    SDL_RenderClear(gRenderer);

    for(int i =0; i < CHARACTERS; i++){
        characters[i].render(getSDLRenderer());
    }

    SDL_RenderPresent(gRenderer);
}



//Loops forever!
void SDLGraphicsProgram::loop(){
  unsigned int sum = 0;
  unsigned int yColumn = 0;
  constexpr int offset = 128;
  // for(int i=0; i < CHARACTERS; ++i){
  //     sum += offset;
  //     if (sum > screenWidth){
  //         yColumn+=offset;
  //         sum =0;
  //     }
  characters[0].init(sum,yColumn,getSDLRenderer());
    // Main loop flag
    // If this is quit = 'true' then the program terminates.
    bool quit = false;
    // Event handler that handles various events in SDL
    // that are related to input and output
    SDL_Event e;
    // Enable text input
    SDL_StartTextInput();



    // While application is running
    while(!quit){
      //Handle events on queue
      while(SDL_PollEvent( &e ) != 0){

        if(e.type == SDL_QUIT){
          quit = true;
        }
      }


      SDL_Delay(250);


      update();
      render();
    }

    //Disable text input
    SDL_StopTextInput();
}

// Get Pointer to Window
SDL_Window* SDLGraphicsProgram::getSDLWindow(){
  return gWindow;
}

// Get Pointer to Renderer
SDL_Renderer* SDLGraphicsProgram::getSDLRenderer(){
  return gRenderer;
}
