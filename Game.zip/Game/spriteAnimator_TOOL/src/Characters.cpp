
#if defined(LINUX) || defined(MINGW)
    #include <SDL2/SDL.h>

#else // This works for Mac
    #include <SDL.h>
#endif

// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include<iostream>
#include<stdio.h>
#include<math.h>
#include<vector>


#include "ResourceManager.hpp"
#include "Characters.hpp"
Characters::Characters(){
  ResourceManager::getInstance().startUp();
}


Characters::~Characters(){

ResourceManager::getInstance().shutdown();


}

// TODO: YUCK! Fix this common resource consumption error.
void Characters::init(int x, int y, SDL_Renderer* ren){
    xPos = x;
    yPos = y;
    ResourceManager::getInstance().init(filePath,ren);
    texture=ResourceManager::getInstance().getTexture();
    // std::cout<<texture->s;
    SDL_Point size;
    SDL_QueryTexture(texture,NULL,NULL,&size.x,&size.y);
    widthImg=size.x;
    heightImg=size.y;
    std::cout<<widthImg<<"\n";
    std::cout<<heightImg<<"\n";
    col=ceil(widthImg/tileWidth);
    row=ceil(heightImg/tileHeight);
    int key=0;
    std::cout<<row<<"\n";
    std::cout<<col<<"\n";
    std::vector<int> vel;
    for(int i=0; i<=row; i++){
      for (int j=0; j<=col;j++){
        tempWidth=j*tileWidth;
        tempHeight=(i)*tileHeight;
        // std::cout<<tempWidth<<"\t"<<tempHeight<<"\n";
        std::vector<int> v1;
        v1.push_back(tempWidth);
        v1.push_back(tempHeight);
        map.insert(make_pair(key,v1));
        key++;
        // std::cout<<"Key is"<<key<<"\n";

        // std::cout<<col<<"\n";


      }
      // std::cout<<"\n";

    }








}


void Characters::update(int x, int y, int frame){

	currentFrame = frame;
	if(currentFrame>lastFrame){
		currentFrame=startFrame;
	}
  std::vector<int> temp=map[currentFrame];


	// Here I am selecting which frame I want to draw
	// from our sprite sheet. Think of this as just
	// using a mouse to draw a rectangle around the
	// sprite that we want to draw.
  std::cout<<currentFrame<<"\n";


  if(temp.size()!=2){
    std::cout<<"Error"<<currentFrame<<"\n";
  }
  else{
    Src.x = temp.at(0);
  	Src.y = temp.at(1);
    Src.w = tileWidth;
    Src.h = tileHeight;

    // Where we want the rectangle to be rendered at.
    // This is an actual 'quad' that will draw our
    // source image on top of.
    Dest.x = xPos;
    Dest.y = yPos;
    Dest.w = 128;
    Dest.h = 128;

  }



}
void Characters::setInformation(std::string filename, int w, int h, int _startFrame, int _lastFrame){
  tileWidth=w;
  tileHeight=h;
  filePath=filename;
  startFrame=_startFrame;
  lastFrame=_lastFrame;

}

void Characters::render(SDL_Renderer* ren){

  SDL_RenderCopyEx(ren, texture, &Src, &Dest, 0.0 , NULL, SDL_FLIP_NONE);


}
