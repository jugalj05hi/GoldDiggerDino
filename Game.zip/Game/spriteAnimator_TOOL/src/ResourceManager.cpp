
#if defined(LINUX) || defined(MINGW)
    #include <SDL2/SDL.h>
#else // This works for Mac
    #include <SDL.h>
#endif

#include <map>
#include <string>
#include <memory>
#include <iterator>

#include "ResourceManager.hpp"

ResourceManager::ResourceManager(){
}


ResourceManager::~ResourceManager(){


}

void ResourceManager::init(std::string filename,SDL_Renderer* ren){


  if ( surfaces.find(filename) == surfaces.end() ) {
    // spriteSheet = SDL_LoadImage(filename.c_str());
    textures = IMG_LoadTexture(ren,filename.c_str());
    if(textures==NULL){
      SDL_Log("No texture loaded as you gave a wrong file as input, please check and try again");
      exit(0);
    }
    surfaces.insert({filename,textures});
    SDL_Log("Allocated a bunch of memory to create identical game character");

  }

}

SDL_Texture* ResourceManager::getTexture(){
  return textures;

}


ResourceManager& ResourceManager::getInstance(){

    static ResourceManager*instance=new ResourceManager();
    return *instance;
}

int ResourceManager::startUp(){
   textures=NULL;
   return 1;
}

int ResourceManager::shutdown(){
  surfaces.clear();

	SDL_DestroyTexture(textures);
  return 1;
}
