// Support Code written by Michael D. Shah
// Last Updated: 2/07/21
// Please do not redistribute without asking permission.

#include "SDLGraphicsProgram.hpp"
#include "ResourceManager.hpp"
#include <string>
#include <stdlib.h>




int main(int argc, char** argv){
	std::string filename=argv[1];
	int tileWidth=atoi(argv[2]);
	int tileHeight=atoi(argv[3]);
	int startFrame=atoi(argv[4]);
	int finalFrame=atoi(argv[5]);


	// Create an instance of an object for a SDLGraphicsProgram
	SDLGraphicsProgram mySDLGraphicsProgram(1280,720);

	// printf("", );
	// Run our program forever
	// std::string filepath=NULL;
	// int width=0;
	// int height=0;
	// int frame1=0;
	// int frame2=0;
	mySDLGraphicsProgram.getSpriteInformation(filename,tileWidth, tileHeight,startFrame,finalFrame);
	// mySDLGraphicsProgram.getSpriteInformation("./sprite.bmp",75,87,3,18);

	mySDLGraphicsProgram.loop();
	// When our program ends, it will exit scope, the
	// destructor will then be called and clean up the program.
	return 0;
}
