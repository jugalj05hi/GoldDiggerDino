/*
 *  @file   GraphicsEngineRenderer.hpp
 *  @brief  GraphicsEngineRenderer class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef GRAPHICS_ENGINE_RENDERER_HPP
#define GRAPHICS_ENGINE_RENDERER_HPP
// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
//
// Note that your path may be different depending on where you intalled things
//
//
#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else // This works for Mac
#include <SDL.h>
#endif
#include <SDL2_image/SDL_image.h>
#include "ResourceManager.hpp"

/**
 * This class serves as an interface to
 * the main graphics renderer for our engine.
 */
class GraphicsEngineRenderer
{
public:
     /*! \brief Constuctor for GraphicsEngineRenderer. Takes in an int for width and height, and a file path as a string.
    * @param int w
    * @param int h
    * @param std::string path
    */
     GraphicsEngineRenderer(int w, int h, std::string path);
     /**
         * Destructor
         */
     ~GraphicsEngineRenderer();
     /**
         * Set the color for the background whenever
         * the color is cleared.
         */
     void render(int x, int y, SDL_Rect *clip = NULL, double angle = 0.0, SDL_Point *center = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE);
     /**
         * Clear the screen
         */
     void SetRenderDrawColor();
     void SetTexture();

     void RenderClear();

     /**
         * Render whatever is in the backbuffer to
         * the screen.
         */
     void RenderPresent();
     /**
         * Get Pointer to Window
         */
     SDL_Window *GetWindow();
     /**
         * Get Pointer to Renderer
         */
     SDL_Renderer *GetRenderer();
     /**
     * Set new texture
     */
     void SetNewTexture(std::string path);
     /**
     * Get Width of texture
     */
     int getWidth();
     /**
     * Get Height of texture
     */
     int getHeight();

private:
     // Screen dimension constants
     int m_screenHeight;
     int m_screenWidth;
     int textureWidth = 0;
     int textureHeight = 0;
     std::string path;
     //SDL Texture background Image
     SDL_Texture *textureBG;
     // SDL Window
     SDL_Window *m_window;
     // SDL Renderer
     SDL_Renderer *m_renderer = nullptr;
     SDL_Rect renderQuad;
     //Create a ResourceManager instance
     ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
