/*
 *  @file   Engine.hpp
 *  @brief  Engine class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef SDLGRAPHICSPROGRAM
#define SDLGRAPHICSPROGRAM

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <time.h>

#include "GraphicsEngineRenderer.hpp"

/**
 * This class sets up the main game engine
 */
class Engine
{
public:
    /**
     * Constructor of Engine
     */
    Engine();
    /**
     * Destructor
     */
    ~Engine();
    /**
     * Input engine
     */
    void Input(bool *quit, bool *startGame);
    /**
     * Per frame update
     */
    void Update();
    /**
     * Per frame render. Renders everything
     */
    void Render();
    /**
     * Start screen Loop
     */
    void StartScreenLoop(bool *quit, bool *startGame);
    /**
     * Main Game Loop that runs forever
     */
    void MainGameLoop();
    /**
     * Initialization and shutdown pattern
     * Explicitly call 'Start' to launch the engine
     */
    void WinScreenLoop(bool *quit, bool *startGame);
    void GameOverScreenLoop(bool *quit, bool *startGame);
    void Start();
    /**
     * Initialization and shutdown pattern
     * Explicitly call 'Shutdown' to terminate the engine
     */
    void Shutdown();

    /**
     * Request to startup the Graphics Subsystem
     */
    void InitializeGraphicsSubSystem();

private:
    // Engine Subsystem
    // Setup the Graphics Rendering Engine
    GraphicsEngineRenderer *m_renderer = nullptr;
};

#endif
