/*
 *  @file   AIComponent.hpp
 *  @brief  AIComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef AICOMPONENT_HPP
#define AICOMPONENT_HPP

#include "Component.hpp"

/*! \brief      AIComponent class used to add movement to a NPC game entity
 */
class AIComponent : public Component
{
public:
    /*! \brief
     * Constructor of AIComponent
     */
    AIComponent();
    /*! \brief
    * Destructor of AIComponent
    */
    ~AIComponent();
    /*! \brief
    * StartUp function to initialize values of AIComponent
    */
    void StartUp();
    /*! \brief
    * Function to safely destroy and shut attributes of AIComponent
    */
    void ShutDown();
    /*! \brief
    * Update function of AIComponent
    * @param entity GameEntity Object
    */
    void Update(GameEntity &entity);

private:
};

#endif