/*
 *  @file   TileComponent.hpp
 *  @brief  TileComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef TILECOMPONENT_HPP
#define TILECOMPONENT_HPP

#include "Component.hpp"
#include <map>
#include <SDL2_image/SDL_image.h>

/*! \brief      TileComponent class used to make tiles 
 */
class TileComponent : public Component
{
public:
    /*! \brief Constuctor for TileComponent. 
    * @param ren Renderer of the Main Game Loop
    */
    TileComponent(SDL_Renderer* ren);
    /*! \brief Destructor for TileComponent.
    */
    ~TileComponent();
    /*! \brief Initializes the attributes for TileComponent
    */
    void StartUp();
    /*! \brief Destroys and frees attributes for TileComponent
   */
    void ShutDown();
    /*! \brief Updates the TileComponent
   * @param entity GameEntity Object
   */
    void Update(GameEntity& entity);
    /*! \brief Renders the TileComponent
    * @param entity GameEntity Object
    */
    void Render(GameEntity &entity);

private:
    SDL_Renderer *renderer;
    SDL_Surface *m_spritesheet;
    std::map<int, std::vector<int>> map;
    int widthImg, heightImg, row, col, tempWidth, tempHeight;
    int tileHeight, tileWidth;
};

#endif
