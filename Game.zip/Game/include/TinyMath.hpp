/*
 *  @file   TinyMath.hpp
 *  @brief  TinyMath class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef TINYMATH_H
#define TINYMATH_H

#include <cmath>
#include <iostream>
// Forward references of each of the structs
struct Vector2D;

// Vector3D performs vector operations with 3-dimensions
// The purpose of this class is primarily for 3D graphics
// applications.
struct Vector2D
{
    // Note: x,y are a convention
    // x,y could be position, but also any 3-component value.
    float x, y;

    // Default conostrutcor
    // 'why default?' https://stackoverflow.com/questions/20828907/the-new-keyword-default-in-c11
    Vector2D() = default;

    // The "Real" constructor we want to use.
    // This initializes the values x,y,z
    Vector2D(float a, float b)
    {
        // TODO:
        x = a;
        y = b;
    }

    // Index operator, allowing us to access the individual
    // x,y,z components of our vector.
    float &operator[](int i)
    {
        // TODO: Discuss with your partner why this works.
        //       There is no code to change here.
        return ((&x)[i]);
    }

    // Index operator, allowing us to access the individual
    // x,y,z components of our vector.
    const float &operator[](int i) const
    {
        // TODO: Discuss with your partner why this works.
        //       There is no code to change here.
        return ((&x)[i]);
    }

    // Multiplication Operator
    // Multiply vector by a uniform-scalar.
    Vector2D &operator*=(float s)
    {
        // TODO:
        x *= s;
        y *= s;
        return (*this);
    }

    // Division Operator
    Vector2D &operator/=(float s)
    {
        // TODO:
        x = x / s;
        y = y / s;

        return (*this);
    }

    // Addition operator
    Vector2D &operator+=(const Vector2D &v)
    {
        // TODO:
        x += v.x;
        y += v.y;
        return (*this);
    }

    // Subtraction operator
    Vector2D &operator-=(const Vector2D &v)
    {
        // TODO:
        x -= v.x;
        y -= v.y;

        return (*this);
    }
};

// Compute the dot product of a Vector3D
inline float Dot(const Vector2D &a, const Vector2D &b)
{
    // TODO:
    float value = (a.x * b.x) + (a.y * b.y);
    return value;
}

// Multiplication of a vector by a scalar values
inline Vector2D operator*(const Vector2D &v, float s)
{
    // TODO:
    Vector2D vec(v.x * s, v.y * s);
    return vec;
}

// Division of a vector by a scalar value.
inline Vector2D operator/(const Vector2D &v, float s)
{
    // TODO:
    Vector2D vec(v.x / s, v.y / s);
    return vec;
}

// Negation of a vector
// Use Case: Sometimes it is handy to apply a force in an opposite direction
inline Vector2D operator-(const Vector2D &v)
{
    // TODO:
    Vector2D vec(-v.x, -v.y);
    return vec;
}

// Return the magnitude of a vector
inline float Magnitude(const Vector2D &v)
{
    return (sqrt(v.x * v.x + v.y * v.y));
}

// Add two vectors together
inline Vector2D operator+(const Vector2D &a, const Vector2D &b)
{
    // TODO:
    Vector2D vec((a.x + b.x), (a.y + b.y));
    return vec;
}

// Subtract two vectors
inline Vector2D operator-(const Vector2D &a, const Vector2D &b)
{
    // TODO:
    Vector2D vec((a.x - b.x), (a.y - b.y));
    return vec;
}

// Vector Projection
inline Vector2D Project(const Vector2D &a, const Vector2D &b)
{
    // TODO:
    float b_len = Magnitude(b);
    b_len *= b_len;
    Vector2D vec = b * (Dot(b, a) / b_len);
    return vec;
}

// Set a vectors magnitude to 1
// Note: This is NOT generating a normal vector
inline Vector2D Normalize(const Vector2D &v)
{
    // TODO:
    assert(Magnitude(v) != 0);
    Vector2D vec(v / Magnitude(v));
    return vec;
}

#endif