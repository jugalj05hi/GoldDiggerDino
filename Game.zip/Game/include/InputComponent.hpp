/*
 *  @file   InputComponent.hpp
 *  @brief  InputComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef INPUTCOMPONENT_HPP
#define INPUTCOMPONENT_HPP

#include "Component.hpp"

/*! \brief      InputComponent class used to change velocity due to keyboard input
 */
class InputComponent : public Component
{
public:
  /*! \brief Constuctor for InputComponent. 
    * 
    */
  InputComponent();
  /*! \brief Destructor for InputComponent.
   *
   */
  ~InputComponent();
  /*! \brief Initializes attributes for InputComponent.
   *
   */
  void StartUp();
  /*! \brief Updates the GameEntity upon keypress
   * @param entity GameEntity object
   */
  void Update(GameEntity& entity);
  /*! \brief Handles the event for GameEntity 
   * @param entity GameEntity object
   */
  void HandleEvent(GameEntity &entity);

private:
  bool backPressed = false;
};

#endif
