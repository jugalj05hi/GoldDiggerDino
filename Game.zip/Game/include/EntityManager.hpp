/*
 *  @file   EntityManager.cpp
 *  @brief  EnitityManager class function implementations
 *  @date   2021-03-12
 ***********************************************/
#ifndef ENTITYMANAGER_HPP
#define ENTITYMANAGER_HPP

#include <map>
#include <memory>
#include <vector>
#include <string>

#include "Constants.hpp"
#include "GameEntity.hpp"

class GameEntity; // forward



/*! \brief      EntityManager class that stores all entities within the game
 */
class EntityManager
{
public:
    /**
     * Constructor of EntityManager
     */
    EntityManager() = default;
    std::map<entityType, std::vector<std::shared_ptr<GameEntity>>> gameEntities;
    /*! \brief Add an entity to the Class
   * @param name An enum of type entityType
   *  @param entity A shared pointer to GameEntity Object
   */
    void AddEntity(entityType name, std::shared_ptr<GameEntity> entity);
    /*! \brief Removing a particular entity from the Class
    * @param name An enum of type entityType
   */
    void ClearVector(entityType name);
    /*! \brief Returns the EntityVector of the class that stores the entities.
    * @param name An enum of type entityType
    * @returns Entity Vector
   */
    std::vector<std::shared_ptr<GameEntity>> GetEntityVector(entityType name);
};

#endif