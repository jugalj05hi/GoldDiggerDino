/*
 *  @file   GameEntity.hpp
 *  @brief  GameEntity class interface
 *  @date   2021-03-12
 ***********************************************/
#ifndef GAMEENTITY_HPP
#define GAMEENTITY_HPP

#include "TinyMath.hpp"
#include "Component.hpp"
#include "Constants.hpp"
#include "EntityManager.hpp"
#include <memory>
#include <vector>
#include <SDL2/SDL.h>

class Component;     // forward declaration
class EntityManager; // forward
/*! \brief     Represents an interactable entity in the game that includes Main Character, NPC, Tiles , and etc.
 */
class GameEntity
{

public:
    /*! \brief      Constructor of GameEntity
    * @param eType an Enum of entityType
    */
    GameEntity(entityType eType);
    
    /*! \brief      Destructor of GameEntity
    */
    ~GameEntity();
    /*! \brief      Initializes attributes for the GameEntity object.
    * @param position A Vector2D object that takes in x&y coordinates for the GameEntity
    * @param velocity A Vector2D object that takes in x&y velocity for the GameEntity
    * @param width The width of the GameEntity
    * @param height The height of the GameEntity
    */
    void StartUp(Vector2D position, Vector2D velocity, int width, int height);
    /*! \brief      Destrotys and free attributes of the GameEntity Class
    */
    void ShutDown();
    /*! \brief      Updates the position of the game entity
    */
    void Update();
    /*! \brief      Renders the object on screen for the GameEntity Class
    */
    void Render();
    /*! \brief      Returns the Rectangle for GameEntity
    * @returns SDL_Rect pointer to the actual Rectangle
    */
    SDL_Rect* GetRectangle();
    /*! \brief      Returns the Event for GameEntity
    * @returns SDL_Event pointer to the actual Rectangle
    */
    SDL_Event GetEvent();
    /*! \brief      Returns the Width of GameEntity
   * @returns Width of the GameEntity
   */
    int GetWidth();
    /*! \brief      Returns the Height of GameEntity
   * @returns Height of the GameEntity
   */
    int GetHeight();
    /*! \brief     Adds different components to the GameEntity
   * @param component Shared pointer to the Component object
   */
    void AddComponent(std::shared_ptr<Component> component);
    /*! \brief     Sets the SDL_Event for GameEntity class
   * @param e SDL_Event
   */
    void SetEvent(SDL_Event& e);
    /*! \brief     Sets EntityManager for GameEntity
   * @param entity A pointer to EntityManager object
   */
    void SetManager(EntityManager* entityManager);
    /*! \brief      Resets the GameEntity
   */
    void Reset();
    Vector2D position;
    Vector2D velocity;
    SDL_RendererFlip flip = SDL_FLIP_NONE;
    SDL_Rect rect;
    SDL_Rect src, dest;
    SDL_Texture* m_texture;
    bool win = false;
    bool lose = false;
    int lives = 3;
    int score = 0;
    bool eatSound = false;
    bool deathSound = false;
    bool collectItemSound = false;
    bool jumpSound = false;
    bool cameraFlag = false;
    int xPosTile = 0;
    std::vector<int> collectablesAvailable;

    int arrayPos = 0;
    bool collectable = false;

    entityType eType;
    bool jumping = false;
    bool isGrounded = false;
    EntityManager* entityManager;
    Vector2D initialPosition;
    Vector2D initialVelocity;

private:
    SDL_Event event;

    int width;
    int height;
    std::vector<std::shared_ptr<Component>> components;
};

#endif
