/*
 *  @file   LifeDisplayComponent.hpp
 *  @brief  LifeDisplayComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef LIFEDISPLAYCOMPONENT_HPP
#define LIFEDISPLAYCOMPONENT_HPP

#include "Component.hpp"
#include <map>
#include <math.h>
#include <string>
#include <memory>
#include <iterator>
#include <SDL2_image/SDL_image.h>
#include <SDL2/SDL.h>
#include "ResourceManager.hpp"

/*! \brief      LifeDisplayComponent class used to show character's HP
 */
class LifeDisplayComponent : public Component
{
public:
    /*! \brief Constuctor for LifeDisplayComponent.
    * @param ren Renderer of the Main Game Loop
    * @param path Path to the texture to be loaded
    */
    LifeDisplayComponent(SDL_Renderer* ren, std::string path);
    /*! \brief Destructor for LifeDisplayComponent
    */
    ~LifeDisplayComponent();
    /*! \brief Initializes the attributes for LifeDisplayComponent
    */
    void StartUp();
    /*! \brief Destroys and frees attributes for LifeDisplayComponent
    */
    void ShutDown();
    /*! \brief Updates the LifeDisplayComponent
    * @param entity GameEntity Object
    */
    void Update(GameEntity& entity);
    /*! \brief Renders the LifeDisplayComponent
    * @param entity GameEntity Object
    */
    void Render(GameEntity &entity);
    SDL_Rect rect1;
    SDL_Rect rect2;
    SDL_Rect rect3;

private:
    SDL_Texture *lifeTexture;
    SDL_Renderer *renderer;
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
