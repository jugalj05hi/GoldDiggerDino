/*
 *  @file   ScoreDisplayComponent.hpp
 *  @brief  ScoreDisplayComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef SCOREDISPLAYCOMPONENT_HPP
#define SCOREDISPLAYCOMPONENT_HPP

#include "Component.hpp"
#include <map>
#include <math.h>
#include <string>
#include <memory>
#include <iterator>
#include <SDL2_image/SDL_image.h>
#include <SDL2_ttf/SDL_ttf.h>
#include <SDL2/SDL.h>
#include "Constants.hpp"
#include "ResourceManager.hpp"

/*! \brief      ScoreDisplayComponent class used to show a GameEntity's score.
 */
class ScoreDisplayComponent : public Component
{
public:
    /*! \brief Constuctor for ScoreDisplayComponent. 
    *
    */
    ScoreDisplayComponent(SDL_Renderer* ren);
    /*! \brief Destructor for ScoreDisplayComponent.
   *
   */
    ~ScoreDisplayComponent();
    /*! \brief Initializes the attributes for ScoreDisplayComponent
    */
    void StartUp();
    /*! \brief Destroys and frees attributes for ScoreDisplayComponent
    */
    void ShutDown();
    /*! \brief Updates the ScoreDisplayComponent
    * @param entity GameEntity Object
    */
    void Update(GameEntity& entity);
    /*! \brief Renders the ScoreDisplayComponent
    * @param entity GameEntity Object
    */
    void Render(GameEntity &entity);
    SDL_Rect rect1;
    SDL_Rect rect2;
    SDL_Rect backgroundRect;

private:
    SDL_Renderer *renderer;
    TTF_Font *scoreFont;
    SDL_Color colorCode={0,0,0};

    SDL_Surface *scoreWordSurface;
    SDL_Texture *scoreWordTexture;

    SDL_Surface *scoreSurface;
    SDL_Texture *scoreTexture;
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
