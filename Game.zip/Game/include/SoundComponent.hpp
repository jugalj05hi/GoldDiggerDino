/*
 *  @file   SoundComponent.hpp
 *  @brief  SoundComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef SOUNDCOMPONENT_HPP
#define SOUNDCOMPONENT_HPP

#include <SDL2/SDL.h>
#include "Component.hpp"
#include "ResourceManager.hpp"

/*! \brief      SoundComponent class used to manage sound effects for GameEntity
 */
class SoundComponent : public Component
{
public:
    /*! \brief Constuctor for SoundComponent. 
    *
    */
    SoundComponent();
    /*! \brief Destructor for SoundComponent.
    *
    */
    ~SoundComponent();
    /*! \brief Initializes the attributes for SoundComponent
    */
    void StartUp();
    /*! \brief Destroys and frees attributes for SoundComponent
    */
    void ShutDown();
    /*! \brief Updates the SoundComponent
   * @param entity GameEntity Object
   */
    void Update(GameEntity& entity);
    /*! \brief Renders the SoundComponent
    * @param entity GameEntity Object
    */
    void Render(GameEntity &entity);

private:
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
