/*
 *  @file   PhysicsComponent.hpp
 *  @brief  PhysicsComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef PHYSICSCOMPONENT_HPP
#define PHYSICSCOMPONENT_HPP

#include "Component.hpp"
 /*! \brief      Enum of type of Collisions i.e. Top, Bottom and etc.
  */
enum collisionType
{
    top,
    left,
    bottom,
    right,
    noCollision
};

/*! \brief      PhysicsComponent class used manage a GameEntity's movement
 */
class PhysicsComponent : public Component
{
public:
    /*! \brief Constuctor for PhysicsComponent. 
    *
    */
    PhysicsComponent();
    /*! \brief Destructor for PhysicsComponent
    */
    ~PhysicsComponent();
    /*! \brief Initializes the attributes for PhysicsComponent
   */
    void StartUp();
    /*! \brief Destroys and frees attributes for PhysicsComponent
    */
    void ShutDown();
    /*! \brief Updates the PhysicsComponent
   * @param entity GameEntity Object
   */
    void Update(GameEntity &entity);

private:
    /*! \brief Heleper function to detect where the collision happened ie top, bottom, left, right or none.
    * @param entity First GameEntity Object
    * @param otherEntity Second GameEntity Object
    * @returns Enum of type collisionType
    */
    collisionType GetCollisionDirection(GameEntity& entity, GameEntity& otherEntity);
    /*! \brief Heleper function to resolve the  collisions happened .
    * @param collision enum of CollisionType
    * @param entity First GameEntity Object
    * @param otherEntity Second GameEntity Object
    */
    void ResolveCollision(collisionType collision, GameEntity& entity, GameEntity& otherEntity);
    /*! \brief Heleper function to check IF the collision happened 
    * @param entity First GameEntity Object
    * @param otherEntity Second GameEntity Object
    * @returns true if collisions happened, otherwise false.
    */
    bool CheckCollisions(GameEntity& entity, GameEntity& otherEntity);
    /*! \brief Heleper function to handle the collision between main character and consumables such as coins
    * @param entity Main Character GameEntity Object
    * @param coins Second GameEntity Object that is consumable by the Main Character
    */
    void HandleCoinCollisions(GameEntity& entity, std::vector<std::shared_ptr<GameEntity>> coins);
    /*! \brief Heleper function to handle the collision between main character and NPC
    * @param entity Main Character GameEntity Object
    * @param npcs Second GameEntity Object that is an NPC
    */
    void HandleNPCCollisions(GameEntity& entity, std::vector<std::shared_ptr<GameEntity>> npcs);
    /*! \brief Heleper function to handle the collision between main character and end flag that player has to capture inorder to win.
    * @param entity Main Character GameEntity Object
    * @param end Second GameEntity Object that is the flag
    */
    void HandleEndFlagCollisions(GameEntity &entity, std::vector<std::shared_ptr<GameEntity>> endFlags);
    int xRenderOffset{0};
    int yRenderOffset{0};
};

#endif