/*
 *  @file   Component.hpp
 *  @brief  Component class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef COMPONENT_HPP
#define COMPONENT_HPP
#include <SDL2/SDL.h>
#include "GameEntity.hpp"
#include "Constants.hpp"

class GameEntity; // Forward Declaration
/*! \brief     The interface class for different components to inherit.
 */
class Component
{
public:
    /*! \brief Constuctor for Component class.
    *
    */
    Component() = default;
    /*! \brief To initalize attributes for children classes.
    *
    */
    virtual void StartUp() {};
    /*! \brief To destroy and free attributes for children classes.
   *
   */
    virtual void ShutDown() {};
    /*! \brief To render objects for children classes.
   * @param entity GameEntity Object
   */
    virtual void Render(GameEntity& entity) {};
    /*! \brief To initalize loadImages for children classes.
   * @param filepath The path of the file to load the image
   * @param ren Renderer of the Main Game Loop
   */
    virtual void LoadImage(std::string filepath, SDL_Renderer* ren) {};
    /*! \brief Handle the events of GameEntity object for children classes.
   * @param entity GameEntity Object
   */
    virtual void HandleEvent(GameEntity& entity) {};
    /*! \brief To update the attributes for children classes.
   * @param entity GameEntity Object
   */
    virtual void Update(GameEntity &entity) = 0;
};

#endif