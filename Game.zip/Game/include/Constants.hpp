/*
 *  @file   Constants.hpp
 *  @brief  Sets values for settings that should not change. 
 *  @date   2021-03-12
 ***********************************************/
#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP
#include <string>
const float SPRITE_VEL = 2.0f;
const float GRAVITY = 0.7f;
const float MAX_GRAVITY = 15.0f;
const float JUMP_VEL = 15.0f;
const int WINDOW_WIDTH = 960;
const int WINDOW_HEIGHT = 640;
const int CHARACTER_HEIGHT = 40;
const int CHARACTER_WIDTH = 40;
const int HEART_SIDE_LENGTH = 100;
const int HEART_START_X_LOCATION = WINDOW_WIDTH - (2 * HEART_SIDE_LENGTH);
const int HEART_START_Y_LOCATION = 0;
const int SCORE_HEIGHT = 20;
const int SCORE_WORD_WIDTH = 100;
const int SCORE_NUMBER_WIDTH = 30;
const int SCORE_WORD_START_X_LOCATION = 10;
const int SCORE_START_Y_LOCATION = 30;
const int SCORE_NUMBER_START_X_LOCATION = SCORE_WORD_START_X_LOCATION + SCORE_WORD_WIDTH;
const int LEVEL_WIDTH = 1920;
const int LEVEL_HEIGHT = 640;
const int TILE_SIZE = 16;
const int COIN_TILE = 5000;
const int ENEMY_TILE = 200;
const int END_FLAG_TILE = 183;
//File Paths
static const std::string TILE_SHEET = "./Assets/images/Terrain.png";
static const std::string WIN_SPRITE="./Assets/images/End.png";
static const std::string COIN_SPRITE="./Assets/images/coin.png";
static const std::string TILE_MAP = "./config/TileMap1.txt";
static const std::string DINO_SPRITE = "Assets/images/newSprite.png";
static const std::string BG_MUSIC = "Assets/sounds/BGM-PinnaParkBeach.wav";
static const std::string END_MUSIC = "Assets/sounds/Ending.wav";
static const std::string WIN_MUSIC = "Assets/sounds/Win.wav";
static const std::string BG_IMAGE = "./Assets/images/BackgroundImage.png";
static const std::string SCREEN_START = "./Assets/images/StartScreen.png";
static const std::string SCREEN_WIN = "./Assets/images/WinScreen.png";
static const std::string SCREEN_LOSE = "./Assets/images/GameOverScreen.png";
static const std::string IMG_HEART = "./Assets/images/heart.png";
static const std::string SCORE_FONT = "./Assets/fonts/emulogic.ttf";
static const std::string EAT_SOUND = "./Assets/sounds/eat.wav";
static const std::string DEATH_SOUND = "./Assets/sounds/death.wav";
static const std::string ITEM_COLLECT_SOUND = "./Assets/sounds/itemCollect.wav";
static const std::string JUMP_SOUND = "./Assets/sounds/jump.wav";
static const std::string ENEMY_AI_SPRITE = "./Assets/images/goomba.png";
// Game level enums
enum entityType
{
    main,
    npc,
    tile,
    coin,
    endFlag,
    deadNPC
};
#endif