/*
 *  @file   GraphicsComponent.hpp
 *  @brief  GraphicsComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef AIGRAPHICSCOMPONENT_HPP
#define AIGRAPHICSCOMPONENT_HPP

#include "Component.hpp"
#include <map>
#include <math.h>
#include "ResourceManager.hpp"
#include <string>
#include <memory>
#include <iterator>
#include <SDL2_image/SDL_image.h>

/*! \brief      GraphicsComponent class used to flip through frames for a GameEntity
 */
class AIGraphicsComponent : public Component
{
public:
    /*! \brief
    * Constructor of AIGraphicsComponent
    * @param ren The Renderer of the main Game Loop
    */
    AIGraphicsComponent(SDL_Renderer* ren);
    /*! \brief
    * Destructor of AIGraphicsComponent
    */
    ~AIGraphicsComponent();
    /*! \brief
    * StartUp function to Initialize attributes of AIGraphicsComponent
    */
    void StartUp();
    /*! \brief
    * Shutdown function to destroy and free attributes of AIGraphicsComponent
    */
    void ShutDown();
    /*! \brief
    * Updates the attributes of AIGraphicsComponent
    * @param entity GameEntity Object 
    */
    void Update(GameEntity& entity);
    /*! \brief
    * Helps Render the AI Entity of AIGraphicsComponent
    * @param entity GameEntity Object
    */
    void Render(GameEntity& entity);
    /*! \brief
    * Loads image to use for graphics
    */
    void LoadImage(std::string filepath, SDL_Renderer *ren);

private:
    SDL_Renderer *renderer;
    SDL_Rect src, dest;
    SDL_Surface *m_spritesheet;
    SDL_Texture *m_texture;
    std::map<int, std::vector<int>> map;

    int frameStart;
    int frameEnd;
    int frame = 0;
    int widthImg, heightImg, row, col, tempWidth, tempHeight;
    int tileHeight, tileWidth;
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
