/*
 *  @file   AIPhysicsComponent.hpp
 *  @brief  AIPhysicsComponent class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef AIPHYSICSCOMPONENT_HPP
#define AIPHYSICSCOMPONENT_HPP

#include "Component.hpp"

// enum collisionType { top, left, bottom, right, noCollision };

/*! \brief      PhysicsComponent class used manage a GameEntity's movement
 */
class AIPhysicsComponent : public Component
{
public:
    /*! \brief Constuctor for PhysicsComponent. 
    *
    */
    AIPhysicsComponent();
    /*! \brief Destructor for PhysicsComponent.
    *
    */
    ~AIPhysicsComponent();
    /*! \brief Initialize attributes for PhysicsComponent.
    *
    */
    void StartUp();
    /*! \brief Destroy attributes for PhysicsComponent.
    *
    */
    void ShutDown();
    /*! \brief Updates the attributes for PhysicsComponent.
    * @param entity GameEntity Object
    */
    void Update(GameEntity &entity);
};

#endif