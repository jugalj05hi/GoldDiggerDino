/*
 *  @file   TileMap.hpp
 *  @brief  TileMap class interface 
 *  @date   2021-03-12
 ***********************************************/
#ifndef TILE_H
#define TILE_H

#include <string>
#include <iostream>
#include <vector>
#include <map>
#include "GraphicsEngineRenderer.hpp"
#include "GameEntity.hpp"
#include "TileComponent.hpp"

/*! \brief      TileMap class is used to create and generate a map.
 */
class TileMap
{
public:
    /*! \brief Constuctor for a TileMap. Takes in a file path for a tile sheet, file for tile map path, level width, level height, tile size, and a renderer.
    * @param std::string tileSheetFileName
    * @param std::string _TileMapPath
    * @param int levelWidth
    * @param int levelHeight
    * @param int _TileSize
    * @param SDL_Renderer ren
    */
    TileMap(std::string tileSheetFileName, std::string _TileMapPath, int levelWidth, int levelHeight, int _TileSize, SDL_Renderer *ren);
    /**
     * Destructor for a tilemap
     */
    ~TileMap();
    /**
     * Temporary function for generating a simple
     * map to display some tiles
     */
    void GenerateSimpleMap(std::vector<int> &collectablesAvailable);
    /**
     * Function for printing text to console
     */
    void PrintMap();
    /**
     * Set the 'type' of tile at an x and y position
     */
    void SetTile(int x, int y, int type);
    /**
     * Return the tile type at an x and y position
     */
    int GetTileType(int x, int y);
    /**
     * Draw all of the tiles in the tilemap
     */
    void Render(SDL_Renderer *ren, int x, std::vector<std::shared_ptr<GameEntity>> &obstacles, std::shared_ptr<GameEntity> mainCharacter);
    /**
     * Helper function to set the tMap i.e. TileMap for reverse look-up in the Tile Atlas
     */
    void setTileSheetMap(int width, int height);

    std::vector<int> getEnemyData();

private:
    // Dimensions of our TileMap and individual tiles.
    // Used for spiltting up the sprite sheet
    int m_Rows;
    int m_Cols;
    // How big each tile is.
    int m_TileWidth;
    int m_TileHeight;
    // size of our tilemap
    int m_MapX;
    int m_MapY;
    // Where our TileMap is rendered
    // An SDL Surface contains pixel data to draw our TileMap
    SDL_Surface *m_TileSpriteSheet;
    SDL_Texture *m_Texture;
    // Stores our tile types
    int *m_Tiles;
    int tileArray;
    int imgWidth;
    int imgHeight;
    // SDL_Texture* mWinTexture;
    // SDL_Texture* mCoinTexture;
    std::map<int, std::vector<int>> tMap;
    std::string tileMapPath;
    std::vector<int> enemyCoordinates;
    SDL_Texture* mCoinTexture;
    SDL_Texture* mWinTexture;
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
