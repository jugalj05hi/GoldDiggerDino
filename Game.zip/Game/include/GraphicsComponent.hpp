/*
 *  @file   GraphicsComponent.hpp
 *  @brief  GraphicsComponent class interface
 *  @date   2021-03-12
 ***********************************************/
#ifndef GRAPHICSCOMPONENT_HPP
#define GRAPHICSCOMPONENT_HPP

#include "Component.hpp"
#include <map>
#include <math.h>
#include "ResourceManager.hpp"
#include <string>
#include <memory>
#include <iterator>
#include <SDL2_image/SDL_image.h>

 /*! \brief      GraphicsComponent class used to flip through frames for a GameEntity
  */
class GraphicsComponent : public Component
{
public:
    /*! \brief      Constructor for GraphicsComponent
    * @param ren Renderer of the main Game Loop
    */
    GraphicsComponent(SDL_Renderer* ren);
    /*! \brief      Destructor for GraphicsComponent
   */
    ~GraphicsComponent();
    /*! \brief      Initializes attributes for GraphicsComponent
   */
    void StartUp();
    /*! \brief      Constructor for GraphicsComponent
   */
    void ShutDown();
    /*! \brief      Selects graphic to render depending on frame
   */
    void Update(GameEntity& entity);
    /*! \brief      Renders graphic
    * @param GameEntity GameEntity Object
    */
    void Render(GameEntity& entity);
    /*! \brief      Loads image to use for graphics
    * @param filepath the FilePath of the Image to be loaded
    * @param SDL_Renderer ren
    */
    void LoadImage(std::string filepath, SDL_Renderer* ren);

private:
    SDL_Renderer* renderer;
    SDL_Rect src, dest;
    SDL_Surface* m_spritesheet;
    SDL_Texture* m_texture;
    std::map<int, std::vector<int>> map;

    int frameStart;
    int frameEnd;
    int frame = 0;
    int widthImg, heightImg, row, col, tempWidth, tempHeight;
    int tileHeight, tileWidth;
    int startTime;
    int animationRate;
    int animationLength;
    // SDL_RendererFlip flip=SDL_FLIP_NONE;



    // int frameStart;
    // int frameEnd;
    // int frame=0;
    //Create a ResourceManager instance
    ResourceManager resourceManager = ResourceManager::getInstance();
};

#endif
