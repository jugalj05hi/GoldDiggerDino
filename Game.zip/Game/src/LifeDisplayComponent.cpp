/*
 *  @file   LifeDisplayComponent.cpp
 *  @brief  LifeDisplayComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "LifeDisplayComponent.hpp"

LifeDisplayComponent::LifeDisplayComponent(SDL_Renderer *ren, std::string path)
{
    renderer = ren;
    lifeTexture = resourceManager.loadTexture(path, ren);
    rect1.x = HEART_START_X_LOCATION;
    rect1.y = HEART_START_Y_LOCATION;
    rect1.w = HEART_SIDE_LENGTH;
    rect1.h = HEART_SIDE_LENGTH;

    rect2.x = HEART_START_X_LOCATION + (HEART_SIDE_LENGTH / 2);
    rect2.y = HEART_START_Y_LOCATION;
    rect2.w = HEART_SIDE_LENGTH;
    rect2.h = HEART_SIDE_LENGTH;

    rect3.x = HEART_START_X_LOCATION + (2 * (HEART_SIDE_LENGTH / 2));
    rect3.y = HEART_START_Y_LOCATION;
    rect3.w = HEART_SIDE_LENGTH;
    rect3.h = HEART_SIDE_LENGTH;
}

LifeDisplayComponent::~LifeDisplayComponent()
{
}

void LifeDisplayComponent::StartUp()
{
}

void LifeDisplayComponent::ShutDown()
{
}

/*! \brief      Renders lives left, based on the number of lives a GameEntity has
* @param GameEntity &entity
*/
void LifeDisplayComponent::Render(GameEntity &entity)
{
    if (entity.lives == 3)
    {
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect1);
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect2);
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect3);
    }
    else if (entity.lives == 2)
    {
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect2);
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect3);
    }
    else if (entity.lives == 1)
    {
        SDL_RenderCopy(renderer, lifeTexture, NULL, &rect3);
    }
}

void LifeDisplayComponent::Update(GameEntity &entity)
{
}
