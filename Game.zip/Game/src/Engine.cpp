/*
 *  @file   Engine.cpp
 *  @brief  Engine class function implementations
 *  @date   2021-03-12
 ***********************************************/
// ==================== Libraries ===================
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <vector>

#include <SDL2_mixer/SDL_mixer.h>
#include <SDL2_ttf/SDL_ttf.h>
// ==================== Header Files ==================
#include "Engine.hpp"
#include "TileMap.hpp"
#include "Constants.hpp"
#include "GameEntity.hpp"
#include "EntityManager.hpp"
// ==================== Component Header Files ==================
#include "AIComponent.hpp"
#include "AIGraphicsComponent.hpp"
#include "GraphicsComponent.hpp"
#include "InputComponent.hpp"
#include "LifeDisplayComponent.hpp"
#include "PhysicsComponent.hpp"
#include "ResourceManager.hpp"
#include "ScoreDisplayComponent.hpp"
#include "SoundComponent.hpp"
#include "Timer.h"
#include "AIPhysicsComponent.hpp"

const int FPS = 60;
const float frameDelay = 1000 / FPS;
int frameCount, timerFPS, lastFrame, fps;

int scrollingOffset;
// Global vector for user

std::vector<std::shared_ptr<GameEntity>> playerVect;
// Obstacle vector
std::vector<std::shared_ptr<GameEntity>> obstacleVect;

std::vector<std::shared_ptr<GameEntity>> enemyVect;

// Create a TileMap
TileMap *myTileMap;

// Create Main Character
std::shared_ptr<GameEntity> mainCharacter;

//CreateEnemyCharacter
std::shared_ptr<GameEntity> enemyCharacter;

//Create a ResourceManager instance
ResourceManager resourceManager = ResourceManager::getInstance();

// Entity Manager
EntityManager *entityManager = new EntityManager();
// Initialization function
// Returns a true or false value based on successful completion of setup.
// Takes in dimensions of window.
Engine::Engine()
{
}

// Proper shutdown and destroy initialized objects
Engine::~Engine()
{
}

// Return Input
void Engine::Input(bool *quit, bool *startGame)
{
    // Event handler that handles various events in SDL
    // that are related to input and output
    SDL_Event e;
    // Enable text input
    SDL_StartTextInput();
    //Handle events on queue
    while (SDL_PollEvent(&e) != 0)
    {
        Mix_Chunk *eatSound = resourceManager.loadWAV(EAT_SOUND);
        // User posts an event to quit
        // An example is hitting the "x" in the corner of the window.
        if (e.type == SDL_QUIT)
        {
            *quit = true;
        }
        else if (e.type == SDL_KEYDOWN)
        {
            if (e.key.keysym.sym == SDLK_ESCAPE)
            {
                *quit = true;
            }
            else if (e.key.keysym.sym == SDLK_q)
            {
                *quit = true;
            }
            else if (e.key.keysym.sym == SDLK_p)
            {
                *startGame = true;
            }
            // when spacebar is added for jump put the below in it
            // mainCharacter->jumpSound = true;
        }
        mainCharacter->SetEvent(e);
    }
}

// Update SDL
void Engine::Update()
{
    enemyCharacter->Update();
    mainCharacter->Update();
}

// Render
// The render function gets called once per loop
void Engine::Render()
{
    // Set the color of the empty framebuffer
    m_renderer->SetRenderDrawColor();
    // Clear the screen to the color of the empty framebuffer
    m_renderer->RenderClear();

    // 64 is tile width
    // later make tile width a constant
    // m_renderer->SetTexture();
    m_renderer->render(scrollingOffset, 0);
    m_renderer->render(scrollingOffset + m_renderer->getWidth(), 0);

    // int xPosTile = (int)(mainCharacter->position.x / TILE_SIZE);
    if (mainCharacter->position.x < WINDOW_WIDTH - mainCharacter->GetWidth() * 1.25 && !mainCharacter->cameraFlag) {
        mainCharacter->xPosTile = 0;
    }
    if (mainCharacter->position.x > WINDOW_WIDTH - mainCharacter->GetWidth() * 1.25 && !mainCharacter->cameraFlag) {
        mainCharacter->cameraFlag = true;
        mainCharacter->xPosTile = (int)(mainCharacter->position.x / TILE_SIZE);
        mainCharacter->position.x = 1;
    }
    if (mainCharacter->xPosTile < 0) {
        mainCharacter->xPosTile = 0;
    }
    if (mainCharacter->position.x < 1 && mainCharacter->cameraFlag)
    {
        mainCharacter->cameraFlag = false;
        mainCharacter->position.x = WINDOW_WIDTH - mainCharacter->GetWidth() * 1.30;
        mainCharacter->xPosTile = 0;
    }
    else if (mainCharacter->xPosTile > (WINDOW_WIDTH / TILE_SIZE))
    {
        mainCharacter->xPosTile = (WINDOW_WIDTH / TILE_SIZE);
    }
    // Render the tile map
    myTileMap->Render(m_renderer->GetRenderer(), mainCharacter->xPosTile, obstacleVect, mainCharacter);
    entityManager->ClearVector(tile);
    entityManager->ClearVector(coin);
    entityManager->ClearVector(endFlag);

    for (auto &g : obstacleVect)
    {
        entityType name = g->eType;
        entityManager->AddEntity(name, g);
        g->Render();
    }

    mainCharacter->Render();
    enemyCharacter->Render();

    // Flip the buffer to render
    m_renderer->RenderPresent();
}
void Engine::StartScreenLoop(bool *quit, bool *startGame)
{
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
    {
        std::cout << "Error" << Mix_GetError() << std::endl;
    }

    Mix_Music *bgn = resourceManager.loadMusic(BG_MUSIC);
    while (!*startGame)
    {
        // plays background music
        if (!Mix_PlayingMusic())
        {
            std::cout << "music off"
                      << "\n";
            Mix_PlayMusic(bgn, -1);
        }
        Input(quit, startGame);
        m_renderer->RenderClear();
        m_renderer->SetTexture();
        m_renderer->RenderPresent();
    }
    m_renderer->SetNewTexture(BG_IMAGE);
}

void Engine::WinScreenLoop(bool *quit, bool *startGame)
{
    Mix_Music *win = resourceManager.loadMusic(WIN_MUSIC);
    Mix_PlayMusic(win, -1);

    m_renderer->SetNewTexture(SCREEN_WIN);

    while (!*quit)
    {
        Input(quit, startGame);
        m_renderer->RenderClear();
        m_renderer->SetTexture();
        m_renderer->RenderPresent();
    }
}

void Engine::GameOverScreenLoop(bool *quit, bool *startGame)
{
    Mix_Music *end = resourceManager.loadMusic(END_MUSIC);
    Mix_PlayMusic(end, -1);

    m_renderer->SetNewTexture(SCREEN_LOSE);

    while (!*quit)
    {
        Input(quit, startGame);
        m_renderer->RenderClear();
        m_renderer->SetTexture();
        m_renderer->RenderPresent();
    }
}
//Loops forever!
void Engine::MainGameLoop()
{
    // Main loop flag
    // If this is quit = 'true' then the program terminates.
    bool quit = false;
    bool startGame = false;
    StartScreenLoop(&quit, &startGame);

    Timer fpsTimer;
    Timer capTimer;
    int countedFrames = 0;
    int frameTicks;
    scrollingOffset = 0;

    // While application is running
    fpsTimer.start();

    while (!quit)
    {

        capTimer.start();
        // Get user input
        Input(&quit, &startGame);

        float avgFPS = countedFrames / (fpsTimer.getTicks() / 1000.f);
        if (avgFPS > 2000000)
        {
            avgFPS = 0;
        }


        Update();
        --scrollingOffset;
        if (scrollingOffset < -(m_renderer->getWidth()))
        {
            scrollingOffset = 0;
        }
        Render();
        ++countedFrames;
        frameTicks = capTimer.getTicks();
        if (frameTicks < SCREEN_TICK_PER_FRAME)
        {
            SDL_Delay(SCREEN_TICK_PER_FRAME - frameTicks);
        }
        if (mainCharacter->win)
        {
            WinScreenLoop(&quit, &startGame);
        }
        if (mainCharacter->lose || mainCharacter->lives == -1)
        {
            GameOverScreenLoop(&quit, &startGame);
        }
    }
    //Disable text input
    SDL_StopTextInput();
    TTF_Quit();
}

void Engine::Start()
{
    TTF_Init();

    // Report which subsystems are being initialized
    if (m_renderer != nullptr)
    {
        std::cout << "Initializing Graphics Subsystem\n";
    }
    else
    {
        std::cout << "No Graphics Subsystem initialized\n";
    }

    mainCharacter = std::make_shared<GameEntity>(GameEntity(main));

    std::shared_ptr<Component> inputComponent = std::make_shared<InputComponent>(InputComponent());
    std::shared_ptr<Component> aiComponent = std::make_shared<AIComponent>(AIComponent());
    std::shared_ptr<Component> physicsComponent = std::make_shared<PhysicsComponent>(PhysicsComponent());
    std::shared_ptr<Component> physicsComponent2 = std::make_shared<PhysicsComponent>(PhysicsComponent());

    std::shared_ptr<Component> graphicsComponent = std::make_shared<GraphicsComponent>(GraphicsComponent(m_renderer->GetRenderer()));
    std::shared_ptr<Component> lifeDisplayComponent = std::make_shared<LifeDisplayComponent>(LifeDisplayComponent(m_renderer->GetRenderer(), IMG_HEART));
    std::shared_ptr<Component> scoreDisplayComponent = std::make_shared<ScoreDisplayComponent>(ScoreDisplayComponent(m_renderer->GetRenderer()));
    std::shared_ptr<Component> soundComponent = std::make_shared<SoundComponent>(SoundComponent());
    std::shared_ptr<Component> aigraphicsComponent = std::make_shared<AIGraphicsComponent>(AIGraphicsComponent(m_renderer->GetRenderer()));
    std::shared_ptr<Component> aiphysicsComponent = std::make_shared<AIPhysicsComponent>(AIPhysicsComponent());

    graphicsComponent->LoadImage(DINO_SPRITE, m_renderer->GetRenderer());
    aigraphicsComponent->LoadImage(ENEMY_AI_SPRITE, m_renderer->GetRenderer());

    mainCharacter->StartUp(Vector2D(0, 290), Vector2D(0, 0), CHARACTER_HEIGHT, CHARACTER_WIDTH);
    mainCharacter->AddComponent(inputComponent);
    mainCharacter->AddComponent(physicsComponent);
    mainCharacter->AddComponent(graphicsComponent);
    mainCharacter->AddComponent(lifeDisplayComponent);
    mainCharacter->AddComponent(scoreDisplayComponent);
    mainCharacter->AddComponent(soundComponent);
    playerVect.push_back(mainCharacter);

    entityManager->AddEntity(main, mainCharacter);
    mainCharacter->SetManager(entityManager);

    myTileMap = new TileMap(TILE_SHEET, TILE_MAP, TILE_SIZE, LEVEL_WIDTH, LEVEL_HEIGHT, m_renderer->GetRenderer());

    // available items array for mainCharacter
    //int *collectablesAvailable;
    std::vector<int> collectablesAvailable;
    // Generate a a simple tilemap
    myTileMap->GenerateSimpleMap(collectablesAvailable);
    mainCharacter->collectablesAvailable = collectablesAvailable;

    std::vector<int> enemyData = myTileMap->getEnemyData();
    std::cout << enemyData.size();
    enemyCharacter = std::make_shared<GameEntity>(GameEntity(npc));
    std::cout << "X " << enemyData.at(2);
    std::cout << "Y " << enemyData.at(3);

    enemyCharacter->StartUp(Vector2D(enemyData.at(2) * TILE_SIZE, (enemyData.at(3) * TILE_SIZE) - 32), Vector2D(1, 0), 32, 32);
    enemyCharacter->AddComponent(aiComponent);
    entityManager->AddEntity(npc, enemyCharacter);
    enemyCharacter->SetManager(entityManager);
    enemyCharacter->AddComponent(physicsComponent2);
    enemyCharacter->AddComponent(aigraphicsComponent);
}

void Engine::Shutdown()
{
    // Shut down our Tile Systems
    if (nullptr != m_renderer)
    {
        delete m_renderer;
    }

    // Destroy our tilemap
    if (nullptr != myTileMap)
    {
        delete myTileMap;
    }
}

void Engine::InitializeGraphicsSubSystem()
{
    // Setup our Renderer
    m_renderer = new GraphicsEngineRenderer(WINDOW_WIDTH, WINDOW_HEIGHT, SCREEN_START);

    if (nullptr == m_renderer)
    {
        exit(1); // Terminate program if renderer
                 // cannot be created.
    }
}
