#include "AIPhysicsComponent.hpp"

AIPhysicsComponent::AIPhysicsComponent()
{
}

AIPhysicsComponent::~AIPhysicsComponent()
{
}

void AIPhysicsComponent::StartUp()
{
}

void AIPhysicsComponent::ShutDown()
{
}

void AIPhysicsComponent::Update(GameEntity &entity)
{
    // m_xPos += mVelX;

    // m_yPos += mVelY;
    //std::cout<<"Physics Component\n";
    //std::cout << "x " << entity.position.x << "y " << entity.position.y<< std::endl;
    //std::cout<<"velocity before"<<entity.velocity.x<<"\n";

    entity.position.x += entity.velocity.x;

    if (entity.position.x < 0)
    {
        // Restrict to left end of the screen
        entity.position.x = 0;
    }
    else if (entity.position.x > (WINDOW_WIDTH - entity.GetWidth()))
    {
        // Restrict to right end of the screen
        entity.position.x = WINDOW_WIDTH - entity.GetWidth();
    }

    if (entity.position.y < 0)
    {
        // Restrict to top end of the screen
        entity.position.y = 0;
    }
    else if (entity.position.y > (WINDOW_HEIGHT - entity.GetHeight()))
    {
        // Restrict to bottom end of the screen
        entity.position.y = WINDOW_HEIGHT - entity.GetHeight();
    }
    entity.rect.x = static_cast<int>(entity.position.x);
    entity.rect.y = static_cast<int>(entity.position.y);
    //std::cout << "After Physics\nx " << entity.position.x << "y " << entity.position.y<< std::endl;
    //std::cout<<"velocity after"<<entity.velocity.x<<"\n";
}
