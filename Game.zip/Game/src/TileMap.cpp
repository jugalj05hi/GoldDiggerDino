/*
 *  @file   TileMap.cpp
 *  @brief  TileMap class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <math.h>
#include "TileMap.hpp"

#include <SDL2_image/SDL_image.h>

TileMap::TileMap(std::string tileSheetFileName, std::string _TileMapPath, int _TileSize, int levelWidth, int levelHeight, SDL_Renderer *ren)
{
    if (nullptr == ren)
    {
        SDL_Log("No valid renderer found");
    }

    m_TileHeight = _TileSize;
    m_TileWidth = _TileSize;
    m_MapX = floor(levelWidth / _TileSize);
    m_MapY = floor(levelHeight / _TileSize);
    tileMapPath = _TileMapPath;
    // Load the TileMap Image
    // This is the image that will get
    // sliced into smaller subsections of individual tiles.
    m_Texture = resourceManager.loadTexture(tileSheetFileName, ren);

    if (m_Texture == nullptr)
    {
        SDL_Log("Failed to allocate texture ");
        std::cout << tileSheetFileName << std::endl;
    }
    else
    {
        SDL_Log("Texture Created from Tile Atlas");
    }
    SDL_Point size;
    SDL_QueryTexture(m_Texture, NULL, NULL, &size.x, &size.y);
    imgWidth = size.x;
    imgHeight = size.y;
    setTileSheetMap(imgWidth, imgHeight);

    // Setup the TileMap array
    // This sets each tile to '0'
    m_Tiles = new int[m_MapX * m_MapY];
    for (int i = 0; i < m_MapX * m_MapY; i++)
    {
        m_Tiles[i] = -1; // Default value is no tile.
    }
}

/*! \brief      Sets values of tile sheet into a map
* @param int width
* @param int height
*/
void TileMap::setTileSheetMap(int width, int height)
{
    int colss = std::floor(height / m_TileHeight);
    int rowss = std::floor(width / m_TileHeight);
    int counter = 1;
    int x = 0, y = 0;
    std::vector<int> tempVector;
    for (int i = 0; i < colss; i++)
    {
        for (int j = 0; j < rowss; j++)
        {
            tempVector.clear();
            tempVector.push_back(x);
            tempVector.push_back(y);
            tMap.insert({counter, tempVector});

            x += m_TileHeight;
            ++counter;
        }
        x = 0;
        y += m_TileHeight;
    }
}

// Destructor
TileMap::~TileMap()
{
    SDL_DestroyTexture(m_Texture);
    // Remove our TileMap
    delete[] m_Tiles;
}

/*! \brief      Helper function to generate a simple map and collectables array
* 
*/
void TileMap::GenerateSimpleMap(std::vector<int> &collectablesAvailable)
{
    // collectablesAvailable = new int[m_MapX * m_MapY];
    int type;
    std::ifstream levelFile(tileMapPath);
    if (levelFile)
    {
        std::cout << "File loaded\n";
    }
    for (int y = 0; y < m_MapY; y++)
    {
        for (int x = 0; x < m_MapX; x++)

        {
            levelFile >> type;
            std::cout << type << " ";
            SetTile(x, y, type);
            if (GetTileType(x, y) == ENEMY_TILE)
            {
                enemyCoordinates.push_back(x);
                enemyCoordinates.push_back(y);
                SetTile(x, y, -1);
            }

            if (GetTileType(x, y) >= COIN_TILE)
            {
                collectablesAvailable.push_back(1);
            }

            else
            {
                collectablesAvailable.push_back(0);
            }
        }
        std::cout << std::endl;
    }
}

/*! \brief      Helper function to print out the tile map to the console
* 
*/
void TileMap::PrintMap()
{
    for (int y = 0; y < m_MapY; y++)
    {
        for (int x = 0; x < m_MapX; x++)
        {
            // std::cout << std::setw(3) << GetTileType(x, y);
        }
        //std::cout << "\n";
    }
}

/*! \brief      Sets a tile a certain type
* @param int x
* @param int y
* @param int type
*/
void TileMap::SetTile(int x, int y, int type)
{
    m_Tiles[y * m_MapX + x] = type;
}

/*! \brief      Gets tile type
* @param int x
* @param int y
*/
int TileMap::GetTileType(int x, int y)
{
    return m_Tiles[y * m_MapX + x];
}

std::vector<int> TileMap::getEnemyData()
{
    return enemyCoordinates;
}

/*! \brief      Renders tiles on a screen
* @param SDL_Renderer ren
* @param int xPos
* @param std::vector<GameEntity *> &obstacles
* @param GameEntity *mainCharacter
*/
void TileMap::Render(SDL_Renderer *ren, int xPos, std::vector<std::shared_ptr<GameEntity>> &obstacles, std::shared_ptr<GameEntity> mainCharacter)
{
    int arrayPos;

    if (nullptr == ren)
    {
        SDL_Log("No valid renderer found");
    }
    if (!obstacles.empty())
    {
        obstacles.clear();
    }

    SDL_Rect Src, Dest;

    for (int y = 0; y < m_MapY; y++)
    {

        for (int x = xPos; x < m_MapX; x++)
        {
            // translates x and y position into an array position, since collectablesAvailable array is 1D not 2D
            if (y == 0)
            {
                arrayPos = x;
            }
            else
            {
                arrayPos = x + (m_MapX * (y));
            }
            // Select our Tile
            int currentTile = GetTileType(x, y);
            if (currentTile > 0)
            {
                if (currentTile == END_FLAG_TILE && currentTile!=COIN_TILE)
                {
                    std::shared_ptr<GameEntity> obstacle = std::make_shared<GameEntity>(GameEntity(endFlag));
                    obstacles.push_back(obstacle);
                    
                    mWinTexture=resourceManager.loadTexture(WIN_SPRITE,ren);
                    obstacles.back()->src.x = 0;
                    obstacles.back()->src.y = 0;
                    obstacles.back()->src.w = 64;
                    obstacles.back()->src.h = 64;

                    obstacles.back()->dest.x = (x - xPos) * m_TileHeight;
                    obstacles.back()->dest.y = y * m_TileHeight;
                    obstacles.back()->dest.w = m_TileHeight;
                    obstacles.back()->dest.h = m_TileHeight;

                    obstacles.back()->m_texture = mWinTexture;

                    obstacles.back()->AddComponent(std::make_shared<TileComponent>(TileComponent(ren)));
                    obstacles.back()->StartUp(Vector2D(obstacles.back()->dest.x, obstacles.back()->dest.y), Vector2D(0, 0), m_TileWidth, m_TileHeight);
                }
                // Checks if tile is a consumable
                if (currentTile >= COIN_TILE && currentTile!=END_FLAG_TILE)
                {

                    if (mainCharacter->collectablesAvailable[arrayPos] == 1)
                    {

                        // GameEntity *obstacle = new GameEntity(tile);
                        std::shared_ptr<GameEntity> obstacle = std::make_shared<GameEntity>(GameEntity(coin));
                        obstacle->collectable = true;
                        // so when you later collect an item you can update the collectableAvailable array in the mainCharacter
                        obstacle->arrayPos = arrayPos;
                        obstacles.push_back(obstacle);

                        mCoinTexture=resourceManager.loadTexture(COIN_SPRITE,ren);
                        obstacles.back()->src.x = 0;
                        obstacles.back()->src.y = 0;
                        obstacles.back()->src.w = 563;
                        obstacles.back()->src.h = 564;

                        obstacles.back()->dest.x = (x - xPos) * m_TileHeight;
                        obstacles.back()->dest.y = y * m_TileHeight;
                        obstacles.back()->dest.w = m_TileHeight;
                        obstacles.back()->dest.h = m_TileHeight;

                        obstacles.back()->m_texture = mCoinTexture;

                        obstacles.back()->AddComponent(std::make_shared<TileComponent>(TileComponent(ren)));
                        obstacles.back()->StartUp(Vector2D(obstacles.back()->dest.x, obstacles.back()->dest.y), Vector2D(0, 0), m_TileWidth, m_TileHeight);
                    }
                }
                // tiles that are obstacles, but are NOT collectable
                else if (currentTile < COIN_TILE && currentTile!=END_FLAG_TILE)

                {
                    // GameEntity *obstacle = new GameEntity(tile);
                    std::shared_ptr<GameEntity> obstacle = std::make_shared<GameEntity>(GameEntity(tile));
                    obstacles.push_back(obstacle);

                    obstacles.back()->src.x = tMap.find(currentTile)->second.at(0);
                    obstacles.back()->src.y = tMap.find(currentTile)->second.at(1);
                    obstacles.back()->src.w = m_TileHeight;
                    obstacles.back()->src.h = m_TileHeight;

                    obstacles.back()->dest.x = (x - xPos) * m_TileHeight;
                    obstacles.back()->dest.y = y * m_TileHeight;
                    obstacles.back()->dest.w = m_TileHeight;
                    obstacles.back()->dest.h = m_TileHeight;

                    obstacles.back()->m_texture = m_Texture;
                    std::shared_ptr<TileComponent> tileComponent = std::make_shared<TileComponent>(TileComponent(ren));

                    obstacles.back()->AddComponent(tileComponent);
                    obstacles.back()->StartUp(Vector2D(obstacles.back()->dest.x, obstacles.back()->dest.y), Vector2D(0, 0), m_TileWidth, m_TileHeight);
                }
            }
        }
    }
}