/*
 *  @file   TileComponent.cpp
 *  @brief  TileComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "TileComponent.hpp"

TileComponent::TileComponent(SDL_Renderer *ren)
{
    renderer = ren;
}

TileComponent::~TileComponent()
{
}

void TileComponent::StartUp()
{
}

void TileComponent::ShutDown()
{
}

/*! \brief      Renders tile on screen
* @param GameEntity &entity
*/
void TileComponent::Render(GameEntity &entity)
{
    SDL_RenderCopy(renderer, entity.m_texture, &entity.src, &entity.dest);
}

void TileComponent::Update(GameEntity &entity)
{
}
