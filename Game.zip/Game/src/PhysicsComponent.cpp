#include "PhysicsComponent.hpp"

PhysicsComponent::PhysicsComponent()
{
}

PhysicsComponent::~PhysicsComponent()
{
}

void PhysicsComponent::StartUp()
{
}

void PhysicsComponent::ShutDown()
{
}

/*! \brief      Updates the position of the Entity and handles any collisions with other game entities
* @param GameEntity& entity
*/
void PhysicsComponent::Update(GameEntity &entity)
{
    float oldXPos = entity.position.x;
    float oldYPos = entity.position.y;
    entity.position.x += entity.velocity.x;

    EntityManager *entityManager = entity.entityManager;
    std::vector<std::shared_ptr<GameEntity>> obstacles = entityManager->GetEntityVector(tile);
    std::vector<std::shared_ptr<GameEntity>> coins = entityManager->GetEntityVector(coin);
    std::vector<std::shared_ptr<GameEntity>> npcs = entityManager->GetEntityVector(npc);
    std::vector<std::shared_ptr<GameEntity>> endFlags = entityManager->GetEntityVector(endFlag);

    if (!entity.isGrounded || entity.eType == entityType::deadNPC)
    {
        entity.velocity.y += GRAVITY;
        if (entity.velocity.y > MAX_GRAVITY)
        {
            entity.velocity.y = MAX_GRAVITY;
        }
        entity.position.y += entity.velocity.y;
    }
    if (entity.velocity.x >= 10)
    {
        entity.velocity.x = 0;
    }
    if (entity.velocity.x < -10)
    {
        entity.velocity.x = 0;
    }

    if (entity.eType == main)
    {
        if (entity.position.x < 0)
        {
            // Restrict to left end of the screen
            entity.position.x = 0;
        }
        else if (entity.position.x > (WINDOW_WIDTH - entity.GetWidth()))
        {
            // Restrict to right end of the screen
            entity.position.x = WINDOW_WIDTH - entity.GetWidth();
        }
    }

    if (entity.position.x < 0)
    {
        // Restrict to left end of the screen
        entity.position.x = 0;
    }
    else if (entity.position.x > (WINDOW_WIDTH - entity.GetWidth()))
    {
        // Restrict to right end of the screen
        entity.position.x = WINDOW_WIDTH - entity.GetWidth();
    }

    if (entity.position.y < 0)
    {
        // Restrict to top end of the screen
        entity.position.y = 0;
    }

  
    bool collisionDetected = false;
    bool touchGround = false;
    for (auto &obstacle : obstacles)
    {
        if (CheckCollisions(entity, *obstacle))
        {
            collisionDetected = true;
            collisionType collision = GetCollisionDirection(entity, *obstacle);
            if (collision == collisionType::left && entity.velocity.x > 0)
            {
                if (entity.eType == npc)
                {
                    if (entity.velocity.x > 0)
                    {
                        entity.velocity.x = -entity.velocity.x;
                    }
                    entity.position.x += entity.velocity.x;
                }
                else
                {
                    entity.position.x = oldXPos;
                }
                xRenderOffset = 5;
            }
            else if (collision == collisionType::right && entity.velocity.x < 0)
            {
                if (entity.eType == npc)
                {
                    if (entity.velocity.x < 0)
                    {
                        entity.velocity.x = -entity.velocity.x;
                    }
                    entity.position.x += entity.velocity.x;
                }
                else
                {

                    entity.position.x = oldXPos;
                }

                xRenderOffset = -5;
            }
            else if (collision == collisionType::bottom && entity.velocity.y < 0)
            {
                entity.position.y = oldYPos;
                yRenderOffset = -5;
            }
            else
            {
                ResolveCollision(collision, entity, *obstacle);
            }
            touchGround = touchGround || (collision == collisionType::top);
        }
    }

    entity.isGrounded = touchGround;
    if (!collisionDetected)
    {
        xRenderOffset = 0;
        yRenderOffset = 0;
    }
    entity.rect.x = static_cast<int>(entity.position.x) + xRenderOffset;
    entity.rect.y = static_cast<int>(entity.position.y) + yRenderOffset;

    if (entity.position.y > (WINDOW_HEIGHT - entity.GetHeight()))
    {
        if (entity.eType == entityType::main)
        {
            entity.Reset();
            for (auto &npc : npcs)
            {
                npc->position = npc->initialPosition;
                npc->velocity = npc->initialVelocity;
                npc->eType = entityType::npc;
            }
        }
    }

    if (entity.eType == entityType::main)
    {
        HandleCoinCollisions(entity, coins);
        HandleNPCCollisions(entity, npcs);
        HandleEndFlagCollisions(entity, endFlags);
    }
}

/*! \brief      Handles all logic related to the main character running into an end game flag
* @param GameEntity& entity
* @param std::vector<std::shared_ptr<GameEntity>> endFlags
*/
void PhysicsComponent::HandleEndFlagCollisions(GameEntity &entity, std::vector<std::shared_ptr<GameEntity>> endFlags)
{
    for (auto &endFlag : endFlags)
    {
        if (CheckCollisions(entity, *endFlag))
        {
            entity.win = true;
        }
    }
}

/*! \brief      Handles all logic related to the main character running into NPC's
* @param GameEntity& entity
* @param std::vector<std::shared_ptr<GameEntity>> npcs
*/
void PhysicsComponent::HandleNPCCollisions(GameEntity &entity, std::vector<std::shared_ptr<GameEntity>> npcs)
{
    bool collisionDetected = false;
    collisionType collision = collisionType::noCollision;
    for (auto &npc : npcs)
    {
        if (CheckCollisions(entity, *npc))
        {
            collisionDetected = true;
            collision = GetCollisionDirection(entity, *npc);
            ResolveCollision(collision, entity, *npc);
        }
    }
    if (collisionDetected && collision != collisionType::top)
    {
        for (auto &npc : npcs)
        {
            npc->position = npc->initialPosition;
            npc->velocity = npc->initialVelocity;
        }
    }
}

/*! \brief      Handles all logic related to the main character running into coins/collectible items
* @param GameEntity& entity
* @param std::vector<std::shared_ptr<GameEntity>> coins
*/
void PhysicsComponent::HandleCoinCollisions(GameEntity &entity, std::vector<std::shared_ptr<GameEntity>> coins)
{
    for (auto &coin : coins)
    {
        if (CheckCollisions(entity, *coin))
        {
            collisionType collision = GetCollisionDirection(entity, *coin);
            ResolveCollision(collision, entity, *coin);
        }
    }
}

/*! \brief      Checks if the first entity has run into the second entity
* @param GameEntity& entity
* @param GameEntity& otherEntity
* @return bool
*/
bool PhysicsComponent::CheckCollisions(GameEntity &entity1, GameEntity &otherEntity)
{

    Vector2D mainEntityPos = entity1.position;
    float mainBottom = mainEntityPos.y + entity1.GetHeight();
    float mainTop = mainEntityPos.y;
    float mainRight = mainEntityPos.x + entity1.GetWidth();
    float mainLeft = mainEntityPos.x;
    Vector2D otherEntityPos = otherEntity.position;
    float otherBottom = otherEntityPos.y + otherEntity.GetHeight();
    float otherTop = otherEntityPos.y;
    float otherRight = otherEntityPos.x + otherEntity.GetWidth();
    float otherLeft = otherEntityPos.x;

    // No contact detected
    if (mainLeft > otherRight)
    {
        return false;
    }
    if (mainRight < otherLeft)
    {
        return false;
    }
    if (mainTop > otherBottom)
    {
        return false;
    }
    if (mainBottom < otherTop)
    {
        return false;
    }

    // Collision Detected
    return true;
}

/*! \brief      Returns the direction (from the second entity's perspective) of the first entity colliding into a second.
* @param GameEntity& entity
* @param GameEntity& otherEntity
* @return collisionType
*/
collisionType PhysicsComponent::GetCollisionDirection(GameEntity &entity1, GameEntity &otherEntity)
{
    Vector2D mainEntityPos = entity1.position;
    float mainBottom = mainEntityPos.y + entity1.GetHeight();
    float mainTop = mainEntityPos.y;
    float mainRight = mainEntityPos.x + entity1.GetWidth();
    float mainLeft = mainEntityPos.x;
    Vector2D otherEntityPos = otherEntity.position;
    float otherBottom = otherEntityPos.y + otherEntity.GetHeight();
    float otherTop = otherEntityPos.y;
    float otherRight = otherEntityPos.x + otherEntity.GetWidth();
    float otherLeft = otherEntityPos.x;

    int bottomCollision = otherBottom - mainTop;
    int topCollision = mainBottom - otherTop;
    int leftCollision = mainRight - otherLeft;
    int rightCollision = otherRight - mainLeft;

    if (topCollision < bottomCollision && topCollision < leftCollision && topCollision < rightCollision)
    {

        return top;
    }
    else if (bottomCollision < topCollision && bottomCollision < leftCollision && bottomCollision < rightCollision)
    {

        return bottom;
    }
    else if (leftCollision < rightCollision && leftCollision < topCollision && leftCollision < bottomCollision)
    {

        return left;
    }
    else if (rightCollision < leftCollision && rightCollision < topCollision && rightCollision < bottomCollision)
    {

        return right;
    }
    else
    {
        return noCollision;
    }
}

/*! \brief      Resolves collisions based on the type of collision, the type of the first entity, and the type of the second entity.
* @param collisionType collision
* @param GameEntity& entity
* @param GameEntity& otherEntity
* @return bool
*/
void PhysicsComponent::ResolveCollision(collisionType collision, GameEntity &entity1, GameEntity &entity2)
{
    if (entity1.eType == entityType::main)
    {
        // Main Character resolution
        if (entity2.eType == entityType::tile)
        {
            // Resolution for tiles
            if (collision == collisionType::left)
            {
                // left
                entity1.position.x = entity2.position.x - entity1.GetWidth();
                xRenderOffset = 5;
            }
            else if (collision == collisionType::right)
            {
                // right
                entity1.position.x = entity2.position.x + entity2.GetWidth();
                xRenderOffset = -5;
            }
            else if (collision == collisionType::top)
            {
                entity1.isGrounded = true;
                entity1.jumping = false;
                entity1.velocity.y = 0;

                entity1.position.y = entity2.position.y - entity1.GetHeight();

                yRenderOffset = 5;
            }
            else if (collision == collisionType::bottom)
            {
                // bottom
                entity1.position.y = entity2.position.y + entity2.GetHeight();
                yRenderOffset = -5;
                entity1.velocity.y = 0;
            }
        }
        else if (entity2.eType == entityType::coin)
        {
            entity1.score = entity1.score + 10;
            entity1.collectItemSound = true;
            entity1.collectablesAvailable[entity2.arrayPos] = 0;
        }
        else if (entity2.eType == entityType::npc)
        {
            if (collision == collisionType::top)
            {
                entity2.eType = entityType::deadNPC;
                entity2.isGrounded = false;
                entity2.velocity.x = 0;
                entity1.isGrounded = false;
                entity1.jumping = true;
                entity1.velocity.y = -JUMP_VEL / 3;
            }
            else
            {
                entity1.Reset();
            }
        }
    }
    else if (entity1.eType == entityType::npc)
    {
        if (entity2.eType == entityType::tile)
        {
            // Resolution for tiles
            if (collision == collisionType::left)
            {
                entity1.position.x = entity2.position.x - entity1.GetWidth();
                xRenderOffset = 5;
            }
            else if (collision == collisionType::right)
            {
                entity1.position.x = entity2.position.x + entity2.GetWidth();
                xRenderOffset = -5;
            }
            else if (collision == collisionType::top)
            {
                entity1.isGrounded = true;
                entity1.jumping = false;
                entity1.velocity.y = 0;

                entity1.position.y = entity2.position.y - entity1.GetHeight();

                yRenderOffset = 5;
            }
            else if (collision == collisionType::bottom)
            {
                // bottom
                entity1.position.y = entity2.position.y + entity2.GetHeight();
                yRenderOffset = -5;
                entity1.velocity.y = 0;
            }
        }
    }
}