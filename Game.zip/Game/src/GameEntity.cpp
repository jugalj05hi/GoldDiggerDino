/*
 *  @file   GameEntity.cpp
 *  @brief  GameEntity class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "GameEntity.hpp"

GameEntity::GameEntity(entityType eType)
{
    this->eType = eType;
}

GameEntity::~GameEntity()
{
    //Empty
}

/*! \brief      Updates the position of the game entity
* @param GameEntity &entity
*/
void GameEntity::StartUp(Vector2D position, Vector2D velocity, int width, int height)
{
    this->position = position;
    this->velocity = velocity;
    this->width = width;
    this->height = height;
    initialPosition = position;
    initialVelocity = velocity;
    rect.x = static_cast<int>(position.x);
    rect.y = static_cast<int>(position.y);
    rect.w = width;
    rect.h = height;
}

/*! \brief Calls all the update functions for each component in GameEntity     
* 
*/
void GameEntity::Update()
{
    for (auto &component : components)
    {
        component->Update(*this);
    }
}

/*! \brief Calls all the render functions for each component in GameEntity     
* 
*/
void GameEntity::Render()
{
    for (auto &component : components)
    {
        component->Render(*this);
    }
}

/*! \brief      Returns the rectangle stored in GameEntity
* 
*/
SDL_Rect *GameEntity::GetRectangle()
{
    return &rect;
}

/*! \brief     Returns the event stored in GameEntity  
* 
*/
SDL_Event GameEntity::GetEvent()
{
    return event;
}

/*! \brief     Returns width of GameEntity
* 
*/
int GameEntity::GetWidth()
{
    return width;
}

/*! \brief     Returns height of GameEntity
* 
*/
int GameEntity::GetHeight()
{
    return height;
}

/*! \brief      Adds component to the component vector in GameEntity
* @param std::shared_ptr<Component> component
*/
void GameEntity::AddComponent(std::shared_ptr<Component> component)
{
    components.push_back(component);
}

/*! \brief      Sets the GameEntity's event attribute to the param 
* @param SDL_Event e
*/
void GameEntity::SetEvent(SDL_Event &e)
{
    event = e;
    for (auto &component : components)
    {
        component->HandleEvent(*this);
    }
}

void GameEntity::SetManager(EntityManager *entityManager)
{
    this->entityManager = entityManager;
}

void GameEntity::Reset() {
    --lives;
    deathSound = true;
    position = initialPosition;
    velocity = initialVelocity;
    if (lives < 0)
        lose = true;
    if (eType == entityType::main)
    {
        xPosTile = 0;
        cameraFlag = false;
    }
}
