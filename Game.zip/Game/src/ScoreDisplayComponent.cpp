/*
 *  @file   ScoreDisplayComponent.cpp
 *  @brief  ScoreDisplayComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "ScoreDisplayComponent.hpp"

ScoreDisplayComponent::ScoreDisplayComponent(SDL_Renderer *ren)
{
    renderer = ren;

    // backgroundRect.x = 0;
    // backgroundRect.y = SCORE_START_Y_LOCATION;
    // backgroundRect.w = SCORE_WORD_WIDTH + SCORE_NUMBER_WIDTH + 15;
    // backgroundRect.h = SCORE_HEIGHT;

    rect1.x = SCORE_WORD_START_X_LOCATION;
    rect1.y = SCORE_START_Y_LOCATION;
    rect1.w = SCORE_WORD_WIDTH;
    rect1.h = SCORE_HEIGHT;

    rect2.x = SCORE_NUMBER_START_X_LOCATION;
    rect2.y = SCORE_START_Y_LOCATION;
    rect2.w = SCORE_NUMBER_WIDTH;
    rect2.h = SCORE_HEIGHT;

    scoreFont = resourceManager.loadFont(SCORE_FONT, 30);

    scoreWordSurface = TTF_RenderText_Solid(scoreFont, "Score: ",colorCode);

    scoreWordTexture = SDL_CreateTextureFromSurface(renderer, scoreWordSurface);
    std::string textV = std::to_string(0);


    scoreSurface = TTF_RenderText_Solid(scoreFont, textV.c_str(), colorCode);

    scoreTexture = SDL_CreateTextureFromSurface(renderer, scoreSurface);
}

ScoreDisplayComponent::~ScoreDisplayComponent()
{
}

void ScoreDisplayComponent::StartUp()
{
}

void ScoreDisplayComponent::ShutDown()
{
}

/*! \brief      Updates score display depending on GameEntity's score
* @param GameEntity &entity
*/
void ScoreDisplayComponent::Render(GameEntity &entity)
{

    SDL_RenderCopy(renderer, scoreWordTexture, NULL, &rect1);
    SDL_RenderCopy(renderer, scoreTexture, NULL, &rect2);
}

/*! \brief      Renders score to screen
* @param GameEntity &entity
*/
void ScoreDisplayComponent::Update(GameEntity &entity)
{
    std::string textScore = std::to_string(entity.score);
    scoreSurface = TTF_RenderText_Solid(scoreFont, textScore.c_str(), colorCode);

    scoreTexture = SDL_CreateTextureFromSurface(renderer, scoreSurface);
}
