/*
 *  @file   InputComponent.cpp
 *  @brief  InputComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "InputComponent.hpp"

InputComponent::InputComponent()
{
}

InputComponent::~InputComponent()
{
}

void InputComponent::StartUp()
{
}

void InputComponent::Update(GameEntity &entity) {}

/*! \brief      Changes GameEntity's velocity depending on key hit
* @param GameEntity &entity
*/
void InputComponent::HandleEvent(GameEntity &entity)
{

    SDL_Event e = entity.GetEvent();
    //If a key was pressed
    if (e.type == SDL_KEYDOWN && e.key.repeat == 0)
    {
        //Adjust the velocity
        switch (e.key.keysym.sym)
        {
        case SDLK_w:
        case SDLK_SPACE:
        case SDLK_UP:
            if (!entity.jumping)
            {
                entity.jumping = true;
                entity.isGrounded = false;
                entity.velocity.y = -JUMP_VEL;
                entity.jumpSound = true;
            }
            break;
        case SDLK_s:
        case SDLK_DOWN:
            break;
        case SDLK_a:
        case SDLK_LEFT:
            entity.velocity.x = -SPRITE_VEL;
            entity.flip = SDL_FLIP_HORIZONTAL;
            backPressed = true;

            break;
        case SDLK_d:
        case SDLK_RIGHT:
            entity.velocity.x = SPRITE_VEL;
            std::cout << entity.position.x << std::endl;
            if (backPressed)
            {
                entity.flip = SDL_FLIP_NONE;
                backPressed = false;
            }
            break;
        default:
            entity.velocity.x = 0;
            break;
        }
    }
    //If a key was released
    else if (e.type == SDL_KEYUP && e.key.repeat == 0)
    {
        //Adjust the velocity
        switch (e.key.keysym.sym)
        {
        case SDLK_w:
        case SDLK_UP:
        case SDLK_SPACE:
            break;
        case SDLK_s:
        case SDLK_DOWN:
            break;
        case SDLK_a:
        case SDLK_LEFT:
            entity.velocity.x = 0;
            break;
        case SDLK_d:
        case SDLK_RIGHT:
            entity.velocity.x = 0;
            break;
        default:
            entity.velocity.x = 0;
            break;
        }
    }
}
