#include "EntityManager.hpp"

/*! \brief      Adds an entity to the appropriate vector of Entity Types
* @param entityType name
* @param std::shared_ptr<GameEntity> entity
*/
void EntityManager::AddEntity(entityType name, std::shared_ptr<GameEntity> entity)
{
    if (gameEntities.count(name) > 0)
    {
        gameEntities[name].push_back(entity);
    }
    else
    {
        gameEntities[name] = std::vector<std::shared_ptr<GameEntity>>{entity};
    }
}

/*! \brief     Clears the vector of items with pass entityType
* @param entityType name
*/
void EntityManager::ClearVector(entityType name)
{
    if (!gameEntities[name].empty())
    {
        gameEntities[name].clear();
    }
}

/*! \brief      Returns the vector of the passed entityType. If it does not exist, it returns an empty vectors
* @param entityType name
* @return std::vector<std::shared_ptr<GameEntity>>
*/
std::vector<std::shared_ptr<GameEntity>> EntityManager::GetEntityVector(entityType name)
{
    if (gameEntities.count(name) > 0)
    {
        return gameEntities[name];
    }
    else
    {
        return std::vector<std::shared_ptr<GameEntity>>{};
    }
}