/*
 *  @file   GraphicsComponent.cpp
 *  @brief  GraphicsComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "GraphicsComponent.hpp"

GraphicsComponent::GraphicsComponent(SDL_Renderer *ren)
{
  renderer = ren;
  m_texture = nullptr;
  frameStart = 0;
  frameEnd = 0;
  frame = 0;
}

GraphicsComponent::~GraphicsComponent()
{
}

void GraphicsComponent::StartUp()
{
}

void GraphicsComponent::ShutDown()
{
}

/*! \brief      Renders graphic
* @param GameEntity &entity
*/
void GraphicsComponent::Render(GameEntity &entity)
{
  SDL_RenderCopyEx(renderer, m_texture, &src, entity.GetRectangle(), 0.0, NULL, entity.flip);
}

/*! \brief      Selects graphic to render depending on frame
* @param GameEntity &entity
*/
void GraphicsComponent::Update(GameEntity &entity)
{

  if (entity.velocity.x > 0 || entity.velocity.x < 0)
  {
    animationLength = 11;
    animationRate = 12;
  }

  else
  {
    animationLength = 2;
    animationRate = 2;
  }

  frame = ((SDL_GetTicks() - startTime) * animationRate / 1000) % animationLength;

  std::vector<int> temp = map[frame];
  src.x = temp.at(0);
  src.y = temp.at(1);
  src.w = 24;
  src.h = 21;
}

/*! \brief      Loads image to use for graphics and uses ResourceManager
* @param std::string filepath
* @param SDL_Renderer ren
*/
void GraphicsComponent::LoadImage(std::string filepath, SDL_Renderer *ren)
{

  m_texture = resourceManager.loadTexture(filepath, ren);
  if (m_texture == nullptr)
  {
    SDL_Log("Failed to allocate texture");
    std::cout << filepath << std::endl;
  }
  else
  {
    SDL_Log("Allocated a bunch of memory to create identical game character");
  }
  SDL_Point size;
  SDL_QueryTexture(m_texture, NULL, NULL, &size.x, &size.y);
  widthImg = size.x;
  heightImg = size.y;

  col = 24;
  row = 1;
  int key = 0;

  tileWidth = widthImg / col;
  tileHeight = heightImg / row;
  std::vector<int> vel;
  for (int i = 0; i < row; i++)
  {
    for (int j = 0; j < col; j++)
    {
      tempWidth = j * tileWidth;
      tempHeight = (i)*tileHeight;
      std::vector<int> v1;
      v1.push_back(tempWidth);
      v1.push_back(tempHeight);
      map.insert(make_pair(key, v1));
      key++;
    }
  }
}
