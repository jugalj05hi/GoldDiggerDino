#include "SoundComponent.hpp"

SoundComponent::SoundComponent()
{
}

SoundComponent::~SoundComponent()
{
}

void SoundComponent::StartUp()
{
}

void SoundComponent::ShutDown()
{
}
void SoundComponent::Render(GameEntity &entity)
{
}

/*! \brief      Plays sound effect if the flag in GameEntity is set to true
* @param GameEntity &entity
*/
void SoundComponent::Update(GameEntity &entity)
{

    if (entity.eatSound)
    {
        Mix_PlayChannel(-1, resourceManager.loadWAV(EAT_SOUND), 0);
        entity.eatSound = false;
    }
    if (entity.deathSound)
    {
        Mix_PlayChannel(-1, resourceManager.loadWAV(DEATH_SOUND), 0);
        entity.deathSound = false;
    }
    if (entity.collectItemSound)
    {
        Mix_PlayChannel(-1, resourceManager.loadWAV(ITEM_COLLECT_SOUND), 0);
        entity.collectItemSound = false;
    }
    if (entity.jumpSound)
    {
        Mix_PlayChannel(-1, resourceManager.loadWAV(JUMP_SOUND), 0);
        entity.jumpSound = false;
    }
}
