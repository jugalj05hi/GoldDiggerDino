/*
 *  @file   AIComponent.cpp
 *  @brief  AIComponent class function implementations
 *  @date   2021-03-12
 ***********************************************/
#include "AIComponent.hpp"

AIComponent::AIComponent()
{
}

AIComponent::~AIComponent()
{
}

void AIComponent::StartUp()
{
}

void AIComponent::ShutDown()
{
}

/*! \brief      Updates the position of the game entity
* @param GameEntity &entity
*/
void AIComponent::Update(GameEntity &entity)
{
  entity.velocity.x += 0.0001;
}
